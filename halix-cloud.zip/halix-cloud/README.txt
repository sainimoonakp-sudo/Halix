ASYNC LABS — Website Cloner
clone. rebuild. ship.

Archived from: https://www.halix.cloud/
Created: 2026-09-19T11:32:13.032Z

Open site/index.html for a simple file-based preview.
Open clone-report.html for the local visual dashboard and site/search.html for offline search.
The dashboard includes page sizes, screenshots, failures, WebGL detection, and canvas animation sampling.
Rendered screenshots, when enabled, are stored under screenshots/.
Photos and image files are grouped under site/assets/images (including external/images).
Audio, video, subtitles, HLS, and DASH use site/assets/media (or site/assets/external/<host>/media).
For ES modules or fetch(), use ASYNC LABS > Browse recent clones > Open local homepage.
Manual verification, when explicitly enabled, opens Brave and never automates CAPTCHA solving.
Interactive features that require the original server may not work offline.
This archive contains only resources that were public and delivered to the browser.
